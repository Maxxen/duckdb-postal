#!/bin/sh
autoreconf -fi --warning=no-portability
